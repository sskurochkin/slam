import "../pages/etalon/etalon.pug";
import "../pages/index/index.pug";
