window.addEventListener('load', function (event) {


	$('.js-show-more').click(function(){
		$(this).toggleClass('active')
		$('.js-paragraph').toggleClass('active')
	})

});

