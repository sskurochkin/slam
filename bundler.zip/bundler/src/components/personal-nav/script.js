window.addEventListener('load', function(event) {

    $('.nav--personal .nav-list').click(function() {
        $(this).toggleClass('active');
    })

});