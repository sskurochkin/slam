module.exports = {
    pages: 'all', // requires pageName or 'all'
    clearLocal: false, //clear local folder before start
    lightMode: true,
};